﻿# Static Web Files

Files and folders placed in this folder 'wwwroot' will be exposed to the internet and statically available.